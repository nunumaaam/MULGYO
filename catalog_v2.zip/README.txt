Mabinogi Mobile NPCShop / 생활도우미 정적 카탈로그 v14

STATUS
- NPCShop static catalog: decoded
- ProductPreset price/reward: decoded
- SymbolTable internal-name bridge: decoded
- Korean reward labels: 2392/2393
- NPCShop-used currency labels: 243/243
- Product sheet rows: 2073
  - fixed: 2067
  - random: 6
- joined Shop -> Tab -> Product relations: 3309

MAIN FILE
npcshop_lifehelper.json
  Joined Shop -> Tab -> Product tree.
  Fixed products include:
  - reward.display_name
  - reward.resolution.sheet_id / source_sheet
  - currency.display_name
  - price / amount / requirements / limits

ALL PRODUCTS
npcshop_products_enriched.json
  Preserves all 2,073 NPCShopProduct rows, including rows not currently
  reachable through the joined Shop tree.

BROWSE FILE
npcshop_catalog_flat.csv
  Flat joined catalog relation view for Excel/import.
  Reused tabs can make the same Product appear in more than one relation.

EXACT RESOLUTION EXAMPLES
- FoodRation -> Consumable SheetId 336977193 -> 여행자 간식
- Bag_Tool_Uncommon -> Bag SheetId 644506942 -> 도구 가방
- LoggingAxe_Tier0 -> EquipmentTool SheetId 1303885935 -> 입문용 벌목 도끼
- CurrencyInfo Gold -> MoneyInfo Gold -> 골드

CURRENCY RESOLUTION
All 243 CurrencyInfo IDs actually used by the 2,393 ProductPreset rows resolve
to a client Korean name through their exact backing data:
- Money -> MoneyInfo
- Consumable -> Consumable
- EventItem -> EventItem

COSTUME PRESETS
CostumePreset names resolve first to CostumeRewardPresetGroup. The JSON then
contains actual gender-specific CostumeSheetId/display-name variants. When
male/female names differ, both are retained.

ONE STATIC SPECIAL CASE
One ProductPreset (id 151573319) has reward type MusicNoteAlbum. It is a
special reward object with no SheetId-backed symbol in MusicNote SymbolTable.
Its Korean display name is deliberately left null instead of being guessed.

RANDOM PRODUCTS
The 6 unique random Product rows retain RandomProductPresetGroupId. Their
currently selected ProductPreset is runtime NPCShop state and is not fabricated
from static package data.
